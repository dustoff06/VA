"""
forge_va_cli.py
================
Standalone, reusable wrapper around the FORGE-VA scoring pipeline.

Two modes:

  fit    SAIL + VAC3 + OIG ground truth  ->  facility scores + saved weights
         (learns rank-biserial feature/block weights from labeled data,
          exactly as in the notebook's main FORGE-VA cell)

  score  SAIL + VAC3 + saved weights     ->  facility scores, NO labels needed
         (applies a previously-fit weighting scheme to new data -- the
          realistic "next quarter came in, re-score it" deployment case)

Usage
-----
  # One-time: fit weights against historical, OIG-labeled data
  python forge_va_cli.py fit \
      --sail SAIL_FY15-FY24_Master.csv \
      --vac3 VAC3_all_years_combined_canon.csv \
      --ground-truth ground_truth_final.csv \
      --weights-out forge_va_weights.json \
      --scores-out forge_va_scores.csv

  # Recurring: score new data with the already-fit weights, no labels needed
  python forge_va_cli.py score \
      --sail SAIL_FY25_Q1_Master.csv \
      --vac3 VAC3_FY25_Q1_canon.csv \
      --weights-in forge_va_weights.json \
      --scores-out forge_va_scores_new.csv

Design notes
------------
- Reuses the exact production algorithms established and validated across
  the FORGE-VA notebooks: SAIL cohort-Z direction adjustment (Block 1),
  VAC3 rolling-4-quarter-baseline residualization + Isolation Forest
  (Block 2), rank-product coupling (Block 3), and rank-biserial
  effect-size weighting -- not approximations of them.
- Facility-name matching to ground truth uses exact match on a normalized
  key (uppercase, alphanumeric only). The notebook's fuzzy-matching /
  recode-dictionary step for OIG report facility names is NOT reproduced
  here, since it's specific to matching free-text OIG report titles, not
  to the SAIL/VAC3 scoring pipeline itself. If your ground-truth file's
  facility keys don't already match SAIL/VAC3's `Facility` column exactly
  after normalization, pre-clean them before calling `fit`.
- `bunching_rate` / `Is_Bunched` naming is kept consistent with the
  production notebook code (see forge_va_manuscript.tex's "reference-point
  proximity" terminology for the conceptual name used in the paper).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import warnings
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import RobustScaler

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================================
# Constants (match the production notebook's specification exactly)
# ============================================================================

ACCESS_CATS = {
    "ED Throughput", "Hospital Flow", "Length of Stay", "Care Transitions",
    "Patient Experience", "Outpatient Performance Measures",
    "Prevention Composite", "Efficiency & Capacity",
}

DIR_MAP = {
    "Ascending": -1, "ascending": -1, "Descending": +1, "descending": +1,
    "Higher": +1, "Lower": -1, "higher is better": +1, "lower is better": -1,
}

CANONICAL_THRESHOLDS = np.array([1.00, 1.645, 1.96, 2.00, 2.58, 3.00])
REFPOINT_TOLERANCE = 0.15          # delta in the manuscript
COORDINATION_THRESHOLD = 0.70
MIN_OBS_PER_MEASURE = 20
ISOLATION_FOREST_PARAMS = dict(
    n_estimators=500, contamination=0.05, random_state=7, bootstrap=False, n_jobs=1
)


def read_table(path: str, **read_csv_kwargs) -> pd.DataFrame:
    """Reads a data file as Parquet or CSV based on its extension, so
    every loader in this wrapper can accept either transparently.
    Parquet files compress SAIL/VAC3-style panel data (repeated
    categorical strings: facility, measure, FY, quarter) 5-10x smaller
    than CSV, which matters for GitHub's 50MB warning / 100MB hard block.
    No CSV-roundtrip conversion happens -- pandas reads Parquet natively
    and just as fast, so there's no reason to decompress back to CSV.
    Requires `pyarrow` (or `fastparquet`) for Parquet: pip install pyarrow.
    `read_csv_kwargs` (e.g. dtype={...}) are applied only for CSV reads;
    Parquet already carries its own column types, so they don't apply
    there and are silently ignored."""
    p = Path(path)
    if p.suffix.lower() in (".parquet", ".pq"):
        try:
            return pd.read_parquet(p)
        except ImportError as e:
            raise ImportError(
                "Reading .parquet files requires the 'pyarrow' package. "
                "Install it with: pip install pyarrow"
            ) from e
    return pd.read_csv(p, low_memory=False, **read_csv_kwargs)


def _normalize_key(s: str) -> str:
    """Uppercase, alphanumeric-only facility key -- consistent join key
    across SAIL, VAC3, and ground truth."""
    if pd.isna(s):
        return ""
    s = str(s).strip().upper()
    return re.sub(r"[^A-Z0-9]", "", s)


def _direction_adjusted_cohort_z(df: pd.DataFrame, score_col: str,
                                  measure_col: str, fy_col: str, q_col: str,
                                  dir_col: str) -> pd.Series:
    """Peer-relative, direction-adjusted Z-score within each
    (measure, FY, quarter) cross-sectional cohort. This is Equation 2 /
    Equation 4 in the manuscript: Z = (x - cohort_mean) / cohort_sd, then
    sign-flipped so higher is always more anomalously favorable."""
    grp = df.groupby([measure_col, fy_col, q_col], dropna=False)
    z_cohort = grp[score_col].transform(lambda x: (x - x.mean()) / (x.std(ddof=1) + 1e-9))
    dir_sign = df[dir_col].map(DIR_MAP).fillna(1).astype(int)
    return z_cohort * dir_sign


def _time_ord(fy: pd.Series, quarter: pd.Series) -> pd.Series:
    """Strictly ordered time index, Equation 1 in the manuscript:
    t = 4*FiscalYear + (Quarter - 1)."""
    fy_int = pd.to_numeric(fy.astype(str).str.extract(r"FY?(\d{2,4})", expand=False), errors="coerce")
    fy_int = fy_int.apply(lambda x: 2000 + x if pd.notna(x) and x < 100 else x)
    q_int = pd.to_numeric(quarter.astype(str).str.extract(r"Q?(\d)", expand=False), errors="coerce")
    return (fy_int - fy_int.min()) * 4 + (q_int - 1)


def rank_norm(s: pd.Series, direction: int = 1) -> pd.Series:
    """Rank-normalize to [0, 1]. direction=-1 flips before ranking.
    EXACT port (uses scipy.stats.rankdata, average-rank method, matching
    the production notebook bit-for-bit rather than pandas' .rank(pct=True),
    which can differ at tie-handling edge cases)."""
    from scipy.stats import rankdata
    x = pd.to_numeric(s, errors="coerce") * direction
    valid = x.notna()
    out = pd.Series(np.nan, index=s.index, dtype=float)
    if valid.sum() > 0:
        out.loc[valid] = rankdata(x.loc[valid], method="average") / valid.sum()
    return out


def effect_size_weight(s_vals, bg_vals) -> tuple[float, float]:
    """Rank-biserial r for one-sided S > bg. Returns (r, p).
    EXACT port -- operates on array-likes (numpy arrays or pandas Series),
    filters to finite values, matching the production notebook bit-for-bit."""
    s_vals = np.asarray(s_vals, dtype=float)
    bg_vals = np.asarray(bg_vals, dtype=float)
    s_vals = s_vals[np.isfinite(s_vals)]
    bg_vals = bg_vals[np.isfinite(bg_vals)]

    if len(s_vals) < 3 or len(bg_vals) < 3:
        return 0.0, 1.0

    U, p = mannwhitneyu(s_vals, bg_vals, alternative="greater")
    r = 2 * U / (len(s_vals) * len(bg_vals)) - 1
    return max(0.0, float(r)), float(p)


def quick_auc(scores: pd.Series, fraud_set: set, bg_set: set) -> float:
    s = scores.dropna()
    m_s = s.index.isin(fraud_set)
    m_b = s.index.isin(bg_set)
    if m_s.sum() < 2 or m_b.sum() < 2:
        return float("nan")
    y = np.array([1] * m_s.sum() + [0] * m_b.sum())
    sc = np.concatenate([s.loc[m_s].values, s.loc[m_b].values])
    return roc_auc_score(y, sc)
