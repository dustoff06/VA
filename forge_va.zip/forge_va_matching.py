"""
forge_va_matching.py -- EXACT port of the production notebook's OIG-to-panel
facility-name matching (cell 27, "Extract Classify Merge" section 4).

Strategy, in order: exact normalized match -> unique containment match ->
RapidFuzz WRatio fuzzy match (score_cutoff=80, ties broken by closest
normalized-string length). Requires the `rapidfuzz` package:
    pip install rapidfuzz
"""
from __future__ import annotations

import pandas as pd
from rapidfuzz import process as rfprocess, fuzz

# EXACT, verbatim from the production notebook.
KNOWN_NAME_FIXES = {
    "SANANTONIO": "SAN ANTONIO",
    "LOSANGELES": "LOS ANGELES",
    "COLUMBIASC": "COLUMBIA SC",
    "WASHINGTONDC": "WASHINGTON DC",
    "STLOUIS": "ST LOUIS",
    "MOUNTAINHOME": "MOUNTAIN HOME",
    "CENTRALIOWA": "CENTRAL IOWA",
    "LITTLEROCK": "LITTLE ROCK",
    "LAKECITY": "LAKE CITY",
    "WESTPALMBEACH": "WEST PALM BEACH",
    "PUGETSOUND": "PUGET SOUND",
    "NEWORLEANS": "NEW ORLEANS",
    "KANSASCITY": "KANSAS CITY",
    "GRANDJUNCTION": "GRAND JUNCTION",
    "BATTLECREEK": "BATTLE CREEK",
    "PALOALTO": "PALO ALTO",
    "SANJUAN": "SAN JUAN",
}

VA_STOPWORDS = [
    "VA MEDICAL CENTER", "VAMC", "VA HEALTH CARE SYSTEM", "VA HEALTHCARE SYSTEM",
    "HEALTH CARE SYSTEM", "HEALTHCARE SYSTEM", "VETERANS HEALTH CARE SYSTEM",
    "VETERANS HEALTHCARE SYSTEM", "VETERANS HOSPITAL", "MEMORIAL VETERANS HOSPITAL",
    "FEDERAL HEALTH CARE CENTER", "MEDICAL CENTER", "HOSPITAL", "SYSTEM",
    "VETERANS", "VA",
]


def normalize_facility_name(x) -> str:
    """Normalize VA facility names for safer matching. EXACT port."""
    s = str(x).upper().strip()
    s = KNOWN_NAME_FIXES.get(s, s)
    for token in VA_STOPWORDS:
        s = s.replace(token, " ")
    s = (
        s.replace(".", " ").replace(",", " ").replace("-", " ")
         .replace("/", " ").replace("&", " AND ")
    )
    return " ".join(s.split())


def build_candidate_lookup(panel_facilities: list[str]) -> pd.DataFrame:
    """`panel_facilities` = the exact facility names in your SAIL/VAC3
    panel (e.g. `master.index.astype(str).str.upper().str.strip().tolist()`)."""
    return pd.DataFrame({
        "candidate": panel_facilities,
        "candidate_norm": [normalize_facility_name(c) for c in panel_facilities],
    })


def robust_facility_match(key: str, candidate_lookup: pd.DataFrame,
                           score_cutoff: int = 80) -> tuple[str | None, float, str]:
    """EXACT port of robust_facility_match: exact normalized match ->
    unique containment match -> RapidFuzz WRatio fuzzy match. Returns
    (matched_candidate_or_None, score, method)."""
    candidate_norms = candidate_lookup["candidate_norm"].tolist()
    key_norm = normalize_facility_name(key)
    if not key_norm:
        return None, 0.0, "blank"

    exact = candidate_lookup[candidate_lookup["candidate_norm"] == key_norm]
    if len(exact) == 1:
        return exact.iloc[0]["candidate"], 100.0, "exact"

    contains = candidate_lookup[
        candidate_lookup["candidate_norm"].apply(lambda c: key_norm in c or c in key_norm)
    ]
    if len(contains) == 1:
        return contains.iloc[0]["candidate"], 95.0, "contains"

    matches = rfprocess.extract(key_norm, candidate_norms, scorer=fuzz.WRatio, limit=5)
    strong = [m for m in matches if m[1] >= score_cutoff]
    if not strong:
        return None, float(matches[0][1]) if matches else 0.0, "unmatched"

    best = min(strong, key=lambda m: abs(len(key_norm) - len(m[0])))
    matched_candidate = candidate_lookup.iloc[best[2]]["candidate"]
    return matched_candidate, float(best[1]), "fuzzy"


def match_ground_truth_fuzzy(panel_index: pd.Index, gt_path: str,
                              key_col: str = "sail_key", label_col: str = "label",
                              score_cutoff: int = 80, low_conf_review: int = 85,
                              ) -> tuple[set, set, set, pd.DataFrame]:
    """Full EXACT port of the notebook's ground-truth matching section.
    Returns (fraud_set, n_set, bg_set, match_audit_df). Prints a match
    audit and flags low-confidence/duplicate matches exactly as the
    notebook does, since those are meant to be reviewed manually, not
    silently trusted."""
    panel_facs = panel_index.astype(str).str.upper().str.strip().tolist()
    candidate_lookup = build_candidate_lookup(panel_facs)

    gt = pd.read_csv(gt_path, dtype=str)
    if key_col not in gt.columns or label_col not in gt.columns:
        raise ValueError(f"Ground truth file must have columns '{key_col}' and '{label_col}'")
    gt[label_col] = gt[label_col].fillna("")

    match_results = gt[key_col].apply(lambda k: robust_facility_match(k, candidate_lookup, score_cutoff))
    gt["matched"] = match_results.apply(lambda x: x[0])
    gt["match_score"] = match_results.apply(lambda x: x[1])
    gt["match_method"] = match_results.apply(lambda x: x[2])
    gt["matched"] = gt["matched"].astype("string").str.upper().str.strip()

    print("Match audit (sorted by score; review low scores carefully):")
    print(gt[[key_col, label_col, "matched", "match_score", "match_method"]]
          .sort_values(["match_score", key_col]).to_string(index=False))

    low_conf = gt[(gt["matched"].isna()) | (gt["match_score"] < low_conf_review)]
    if len(low_conf) > 0:
        print("\nLOW-CONFIDENCE / UNMATCHED FACILITIES -- review manually:")
        print(low_conf[[key_col, label_col, "matched", "match_score", "match_method"]].to_string(index=False))
    else:
        print(f"\nAll GT facilities matched with score >= {low_conf_review}.")

    dup_matches = (
        gt.dropna(subset=["matched"]).groupby("matched")
          .filter(lambda x: len(x) > 1).sort_values("matched")
    )
    if len(dup_matches) > 0:
        print("\nDUPLICATE PANEL MATCHES -- inspect manually:")
        print(dup_matches[[key_col, label_col, "matched", "match_score", "match_method"]].to_string(index=False))

    gt_labeled = gt[gt[label_col].isin(["S", "N", "A"])].copy()
    oig_matched = set(gt_labeled["matched"].dropna().astype(str).str.upper())
    fraud_set = set(gt_labeled.loc[gt_labeled[label_col] == "S", "matched"].dropna().astype(str).str.upper())
    n_set = set(gt_labeled.loc[gt_labeled[label_col] == "N", "matched"].dropna().astype(str).str.upper())
    bg_set = set(panel_index.astype(str).str.upper().str.strip()) - oig_matched

    return fraud_set, n_set, bg_set, gt
