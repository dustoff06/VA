"""
forge_va_block2.py -- VAC3 Behavioral Signal (Block 2)

EXACT port of the production notebook's VAC3 feature-engineering cell
(SE-based normalization cell + Isolation Forest cell), not an
approximation. Every formula below is copied from the notebook
`For_Upload_to_GITHUB.ipynb`, including:

  - SE-based Z-scores against real National_Benchmark / Regional_Benchmark
    columns (Z_vs_National = (Score - National_Benchmark) / SE, where
    SE = Group_SD / sqrt(Group_N) -- a standard-error-scaled Z, not a
    population-SD cohort Z).
  - Direction-signed Z (Z_nat_signed / Z_reg_signed), GoodZ (ReLU),
    Z_delta (national-vs-regional gap), Measure_Difficulty_Weight,
    GoodZ_Weighted.
  - Rolling-4-quarter baseline residualization (Z_baseline / Z_resid /
    Z_resid_delta / Z_resid_roll_std4).
  - TSLF (time since last "good" quarter flag).
  - Facility_Consistency_SD, Pct_Measures_Improving, reference-point
    proximity (Min_Dist_to_Threshold / Is_Bunched -- "bunching" in the
    code, "reference-point proximity" in the manuscript's terminology).
  - The EXACT Mahalanobis distance: global covariance (not per-measure-
    group) across the 8-feature set
    [Z_resid, Z_resid_delta, Z_resid_roll_std4, GoodZ_nat, Z_delta,
     GoodZ_Weighted, Facility_Consistency_SD, Pct_Measures_Improving],
    via scipy.spatial.distance.mahalanobis row-by-row against the
    feature-set mean and inverse covariance matrix.
  - Isolation Forest fit separately per canonical measure group on the
    11-feature final_feature_cols set (including Mahalanobis_D itself).

No step here is approximated. If your VAC3 extract lacks
National_Benchmark / Regional_Benchmark columns, this will raise rather
than silently fall back to a cohort-Z proxy -- that fallback lived in an
earlier version of this wrapper and produced numbers that were close but
not exact; see git history / conversation record if you need it back for
some other purpose.
"""
from __future__ import annotations

import re
import math

import numpy as np
import pandas as pd
from scipy import linalg
from scipy.spatial.distance import mahalanobis
from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import RobustScaler

from forge_va_core import _normalize_key, read_table

# ---- exact constants from the production notebook ----
MIN_OBS_PER_MEASURE = 20
GOOD_Z_MIN = 0.0
ANOMALY_QUANTILE = 0.95
CANONICAL_THRESHOLDS = [1.0, 1.645, 1.96, 2.0, 2.58, 3.0]
BUNCHING_WINDOW = 0.15
MAHALANOBIS_FEATURES = [
    "Z_resid", "Z_resid_delta", "Z_resid_roll_std4", "GoodZ_nat",
    "Z_delta", "GoodZ_Weighted", "Facility_Consistency_SD", "Pct_Measures_Improving",
]
FINAL_FEATURE_COLS = [
    "Z_resid", "Z_resid_delta", "Z_resid_roll_std4", "GoodZ_nat", "Z_delta",
    "Mahalanobis_D", "TSLF", "GoodZ_Weighted", "Facility_Consistency_SD",
    "Pct_Measures_Improving", "Min_Dist_to_Threshold",
]
ISOLATION_FOREST_PARAMS = dict(
    n_estimators=500, contamination=1 - ANOMALY_QUANTILE,
    random_state=7, bootstrap=False, n_jobs=1,
)


def _fy_to_year(s) -> float:
    if pd.isna(s):
        return np.nan
    m = re.search(r"(\d{2,4})", str(s))
    if not m:
        return np.nan
    y = int(m.group(1))
    return 2000 + y if y < 100 else y


def _q_to_int(q) -> float:
    if pd.isna(q):
        return np.nan
    m = re.search(r"(\d)", str(q))
    return float(m.group(1)) if m else np.nan


def _max_streak(flags: list) -> int:
    if not flags:
        return 0
    m = cur = 0
    for v in flags:
        if v:
            cur += 1
        else:
            m, cur = max(m, cur), 0
    return max(m, cur)


def load_vac3(vac3_path: str) -> pd.DataFrame:
    df = read_table(vac3_path, dtype={"FY": str, "Quarter": str})
    for col in ("FY", "Quarter"):
        if col in df.columns:
            df[col] = df[col].astype(str)
    required = {"Facility", "Measure", "Score", "Direction", "FY", "Quarter",
                "National_Benchmark", "Regional_Benchmark"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"VAC3 file missing required columns for EXACT Block 2 "
            f"construction: {missing}. National_Benchmark and "
            f"Regional_Benchmark in particular are required for the "
            f"SE-based Z-score -- there is no approximated fallback here."
        )
    df["Measure"] = df["Measure"].apply(lambda s: s.strip() if isinstance(s, str) else s)
    df = df[~df["Measure"].isna() & (df["Measure"] != "")].copy()
    df["Facility"] = df["Facility"].astype(str).str.strip().str.upper()
    df["_fac_key"] = df["Facility"]  # matches real pipeline's index: uppercase/stripped Facility, not a collapsed key
    for col in ["Score", "National_Benchmark", "Regional_Benchmark"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def _se_based_normalization(df: pd.DataFrame) -> pd.DataFrame:
    """Exact port of the 'VAC3 normalization vs National & Regional
    benchmarks (SE-based)' cell."""
    df = df.copy()
    valid_nat = df["Score"].notna() & df["National_Benchmark"].notna()
    valid_reg = df["Score"].notna() & df["Regional_Benchmark"].notna()

    grp = ["Measure", "FY", "Quarter"]
    gcount = df[df["Score"].notna()].groupby(grp)["Score"].count().rename("Group_N")
    gsd = df[df["Score"].notna()].groupby(grp)["Score"].std(ddof=1).rename("Group_SD")
    gmean = df[df["Score"].notna()].groupby(grp)["Score"].mean().rename("Group_Mean")
    df = df.merge(gcount, on=grp, how="left").merge(gsd, on=grp, how="left").merge(gmean, on=grp, how="left")
    df["SE"] = df["Group_SD"] / (df["Group_N"] ** 0.5)

    n = df["Group_N"].values
    se = df["SE"].values
    score = df["Score"].values
    nat_bench = df["National_Benchmark"].values
    reg_bench = df["Regional_Benchmark"].values

    z_nat = np.where(
        valid_nat.values & (n >= 2) & (se != 0) & ~pd.isna(se),
        (score - nat_bench) / se, np.nan,
    )
    z_reg = np.where(
        valid_reg.values & (n >= 2) & (se != 0) & ~pd.isna(se),
        (score - reg_bench) / se, np.nan,
    )
    df["Z_vs_National"] = z_nat
    df["Z_vs_Regional"] = z_reg
    return df


def _build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = _se_based_normalization(df)

    # ---- direction-signed Z (cell17's own Direction_clean, exact) ----
    df["Direction_clean"] = (
        df["Direction"].astype(str).str.strip().str.lower().replace({"h": "higher", "l": "lower"})
    )
    dir_lower = df["Direction_clean"]
    df["Z_nat_signed"] = np.where(dir_lower == "higher", df["Z_vs_National"], -df["Z_vs_National"])
    df["Z_reg_signed"] = np.where(dir_lower == "higher", df["Z_vs_Regional"], -df["Z_vs_Regional"])

    df["GoodZ_nat"] = np.clip(df["Z_nat_signed"], 0, None)
    df["GoodZ_reg"] = np.clip(df["Z_reg_signed"], 0, None)
    df["Z_delta"] = df["Z_nat_signed"] - df["Z_reg_signed"]

    # ---- measure difficulty weighting ----
    df["Measure_Difficulty_Weight"] = 1.0 / df["Group_SD"]
    is_inf = df["Measure_Difficulty_Weight"].isin([np.inf, -np.inf])
    df.loc[is_inf, "Measure_Difficulty_Weight"] = 1000
    df["Measure_Difficulty_Weight"] = df["Measure_Difficulty_Weight"].fillna(0)
    df["GoodZ_Weighted"] = df["GoodZ_nat"] * df["Measure_Difficulty_Weight"]

    # ---- time encodings ----
    df["Year"] = df["FY"].apply(_fy_to_year)
    df["Qnum"] = df["Quarter"].apply(_q_to_int)
    df["time_ord"] = (
        pd.to_numeric(df["Year"], errors="coerce").fillna(0).astype(int) * 4
        + (pd.to_numeric(df["Qnum"], errors="coerce").fillna(1).astype(int) - 1)
    )
    df = df.sort_values(["_fac_key", "Measure", "time_ord"], kind="mergesort").reset_index(drop=True)

    # ---- panel-wise baseline, residuals, TSLF ----
    g = df.groupby(["_fac_key", "Measure"], dropna=False, group_keys=False)
    roll_mean = g["Z_nat_signed"].transform(lambda x: x.rolling(window=4, min_periods=2).mean().shift(1))
    df["Z_baseline"] = roll_mean.fillna(g["Z_nat_signed"].transform("mean"))
    df["Z_baseline"] = df["Z_baseline"].fillna(df["Z_nat_signed"].mean())

    df["Z_resid"] = df["Z_nat_signed"] - df["Z_baseline"]
    df["Z_resid_lag"] = g["Z_resid"].shift(1)
    df["Z_resid_delta"] = df["Z_resid"] - df["Z_resid_lag"]
    df["Z_resid_roll_std4"] = g["Z_resid"].transform(lambda x: x.rolling(window=4, min_periods=2).std())

    df["is_good"] = (df["Z_nat_signed"] > 1.0).astype(int)

    def _tslf(series: pd.Series) -> pd.Series:
        out, last_good = [], None
        for i, flag in enumerate(series):
            if flag == 1:
                out.append(0)
                last_good = i
            else:
                out.append(np.nan if last_good is None else i - last_good)
        return pd.Series(out, index=series.index)

    df["TSLF"] = g["is_good"].apply(_tslf)
    df["TSLF"] = df["TSLF"].clip(lower=0)

    # ---- facility consistency ----
    fac_q = df.groupby(["_fac_key", "time_ord"], dropna=False)
    df["Facility_Consistency_SD"] = fac_q["Z_nat_signed"].transform("std")

    # ---- coordinated improvement ----
    df["Pct_Measures_Improving"] = fac_q["Z_resid_delta"].transform(
        lambda x: (x > 0).mean() if x.notna().sum() > 0 else np.nan
    )

    # ---- reference-point proximity ("bunching" in code) ----
    def _min_dist(z):
        if pd.isna(z):
            return np.nan
        return min(abs(z - t) for t in CANONICAL_THRESHOLDS)

    df["Min_Dist_to_Threshold"] = df["Z_nat_signed"].apply(_min_dist)
    df["Is_Bunched"] = (df["Min_Dist_to_Threshold"] <= BUNCHING_WINDOW).astype(int)
    df["Facility_Quarter_Bunching_Rate"] = fac_q["Is_Bunched"].transform("mean")

    return df


def _calculate_mahalanobis_distance(df: pd.DataFrame, features: list) -> pd.Series:
    """EXACT port of calculate_mahalanobis_distance -- global covariance
    (across the whole dataset, NOT per measure group), row-by-row scipy
    mahalanobis() against the feature-set mean and inverse covariance."""
    X = df[features].dropna().values
    if X.shape[0] < X.shape[1] + 1:
        return pd.Series(np.nan, index=df.index)

    mu = X.mean(axis=0)
    sigma = np.cov(X, rowvar=False)
    try:
        VI = linalg.inv(sigma)
    except linalg.LinAlgError:
        print("Warning: Covariance matrix is singular, Mahalanobis distance skipped.")
        return pd.Series(np.nan, index=df.index)

    mu_dict = dict(zip(features, mu))
    X_full = df[features].fillna(mu_dict).values
    distances = [mahalanobis(X_full[i], mu, VI) for i in range(len(X_full))]
    return pd.Series(np.array(distances), index=df.index)


def _fit_isolation_forest_per_measure(df: pd.DataFrame, group_col: str) -> pd.Series:
    """EXACT port of the per-measure Isolation Forest loop."""
    imputer = SimpleImputer(strategy="median", fill_value=0.0)
    scaler = RobustScaler()
    results = []

    for _, gdf in df.groupby(group_col, dropna=False):
        if gdf.empty:
            continue
        n_obs = len(gdf)
        if n_obs < MIN_OBS_PER_MEASURE:
            results.append(gdf.assign(IF_anomaly_score=np.nan))
            continue

        X = gdf[FINAL_FEATURE_COLS].copy()
        valid_cols = X.columns[X.notna().any(axis=0)].tolist()
        if len(valid_cols) < 2:
            results.append(gdf.assign(IF_anomaly_score=0.0))
            continue

        try:
            imputer.fit(X[valid_cols])
            X_imp = imputer.transform(X[valid_cols])
        except Exception:
            results.append(gdf.assign(IF_anomaly_score=0.0))
            continue

        if np.max(np.std(X_imp, axis=0)) == 0:
            results.append(gdf.assign(IF_anomaly_score=0.0))
            continue

        X_scaled = scaler.fit_transform(X_imp)
        try:
            iso = IsolationForest(**ISOLATION_FOREST_PARAMS, max_samples=min(256, int(n_obs * 0.75)))
            iso.fit(X_scaled)
            scores = -iso.score_samples(X_scaled)
            results.append(gdf.assign(IF_anomaly_score=scores))
        except Exception:
            results.append(gdf.assign(IF_anomaly_score=np.nan))

    return pd.concat(results).sort_index()["IF_anomaly_score"]


def compute_block2(vac3: pd.DataFrame) -> pd.DataFrame:
    """Full, exact Block 2 pipeline. Returns a facility-indexed
    (`_fac_key`) DataFrame with every sub-feature the production
    notebook's fac_summary rollup produces, including the EXACT
    (non-approximated) Mahalanobis distance."""
    df = _build_features(vac3)

    df["Mahalanobis_D"] = _calculate_mahalanobis_distance(df.copy(), MAHALANOBIS_FEATURES)

    group_col = "Measure_canon" if "Measure_canon" in df.columns else "Measure"
    df["IF_anomaly_score"] = _fit_isolation_forest_per_measure(df, group_col)

    raw_scores = df["IF_anomaly_score"].values
    valid = np.isfinite(raw_scores)
    if valid.sum() == 0:
        threshold = np.inf
        df["IF_flag_all"] = 0
    else:
        threshold = np.quantile(raw_scores[valid], ANOMALY_QUANTILE)
        df["IF_flag_all"] = (df["IF_anomaly_score"] >= threshold).astype(int)

    good_side = df["Z_nat_signed"] > GOOD_Z_MIN
    df["IF_good_flag"] = ((df["IF_flag_all"] == 1) & good_side).astype(int)

    # ---- exact facility-level rollup, matching fac_summary in the notebook ----
    df["_time_sort"] = df["time_ord"]
    fac_groups = df.sort_values(["_fac_key", "_time_sort", "Measure"]).groupby("_fac_key", dropna=False)

    fac_summary = pd.DataFrame({
        "records": fac_groups.size(),
        "mean_anom": fac_groups["IF_anomaly_score"].mean(),
        "p95_anom": fac_groups["IF_anomaly_score"].quantile(0.95),
        "pct_flagged_good": fac_groups["IF_good_flag"].mean(),
        "pct_flagged_all": fac_groups["IF_flag_all"].mean(),
        "unique_measures": fac_groups["Measure"].nunique(),
        "years_covered": fac_groups["Year"].nunique(),
        "mean_mahalanobis": fac_groups["Mahalanobis_D"].mean(),
        "p95_mahalanobis": fac_groups["Mahalanobis_D"].quantile(0.95),
        "mean_z_consistency_sd": fac_groups["Facility_Consistency_SD"].mean(),
        "mean_goodz_weighted": fac_groups["GoodZ_Weighted"].mean(),
        "max_tslf": fac_groups["TSLF"].max(),
        "bunching_rate": fac_groups["Is_Bunched"].mean(),
        "mean_bunching_rate_per_quarter": fac_groups["Facility_Quarter_Bunching_Rate"].mean(),
        "p95_bunching_rate": fac_groups["Facility_Quarter_Bunching_Rate"].quantile(0.95),
        "mean_dist_to_threshold": fac_groups["Min_Dist_to_Threshold"].mean(),
        "mean_pct_improving": fac_groups["Pct_Measures_Improving"].mean(),
        "p95_pct_improving": fac_groups["Pct_Measures_Improving"].quantile(0.95),
        "sd_pct_improving": fac_groups["Pct_Measures_Improving"].std(),
    })

    streaks = []
    for fac, grp in df.sort_values(["_fac_key", "_time_sort"]).groupby("_fac_key", dropna=False):
        streaks.append((fac, _max_streak(grp["IF_good_flag"].tolist())))
    streak_df = pd.DataFrame(streaks, columns=["_fac_key", "max_good_flag_streak"]).set_index("_fac_key")
    fac_summary = fac_summary.join(streak_df, how="left")

    fac_summary["bunching_x_improving"] = (
        fac_summary["bunching_rate"].fillna(0) * fac_summary["mean_pct_improving"].fillna(0)
    )

    fac_summary.index.name = "_fac_key"
    return fac_summary
