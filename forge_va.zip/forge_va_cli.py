#!/usr/bin/env python3
"""
forge_va_cli.py -- run the FORGE-VA scoring pipeline end to end.

  fit    python forge_va_cli.py fit   --sail S.csv --vac3 V.csv \\
             --ground-truth GT.csv --weights-out W.json --scores-out OUT.csv

  score  python forge_va_cli.py score --sail S.csv --vac3 V.csv \\
             --weights-in W.json --scores-out OUT.csv

Block 1 (SAIL) and Block 2 (VAC3) are EXACT ports of the production
notebook -- SE-based normalization, the full residual/Mahalanobis/
Isolation Forest chain, and the exact dual-framing effect-size weighting
(build_weighted_score_dual). Ground-truth facility matching is also an
EXACT port of the notebook's fuzzy matcher (forge_va_matching.py). Both
`fit` and `score` build the analytic panel the same way (VAC3/Block 2
defines the panel; SAIL/Block 1 is left-joined onto it), and ground
truth is matched against that same panel rather than a broader
SAIL/VAC3 union.

One remaining known gap: even with panel construction and ground-truth
matching now consistent, facility counts may still not land on exactly
your published Table 3 numbers. Block 3/ensemble here has no artificial
floor on missing block scores (a facility missing Block 1 or Block 2
data correctly gets NaN downstream, matching confirmed real-pipeline
behavior), but build_weighted_score_dual still computes a partial
ensemble score from whichever of score_b1/score_b2/score_b3 are
present rather than requiring all three -- which may not exactly match
a completeness filter in the source notebook that hasn't been located
yet. See forge_va_fit.py's module docstring for the history of this
investigation.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from forge_va_block1 import load_sail, compute_block1
from forge_va_block2 import load_vac3, compute_block2
from forge_va_fit import (
    build_blocks, build_ensemble, save_weights, load_weights,
    score_with_fixed_weights,
)
from forge_va_matching import match_ground_truth_fuzzy
from forge_va_core import quick_auc


def _classify(master: pd.DataFrame, top_pct: float = 0.10) -> pd.Series:
    """Simple audit-priority tier from the ensemble rank -- NOT a
    calibrated probability. 'High' = top decile of forge_va by default;
    adjust --top-pct to match your actual audit capacity."""
    n = master["forge_va"].notna().sum()
    cutoff_rank = max(1, int(np.ceil(n * top_pct)))
    return np.where(
        master["forge_va"].isna(), "insufficient_data",
        np.where(master["forge_rank"] <= cutoff_rank, "high_priority", "routine"),
    )


def _report_top_k(master: pd.DataFrame, top_k: int | None, scores_out: str) -> None:
    """Prints a clean top-K table to console and saves it to its own CSV
    (<scores_out base>_topK.csv), ranked by forge_va descending. Rows
    with NaN forge_va (insufficient data to score) are excluded, since
    they cannot be meaningfully ranked."""
    if not top_k or top_k <= 0:
        return

    ranked = master.dropna(subset=["forge_va"]).sort_values("forge_va", ascending=False)
    top = ranked.head(top_k).copy()
    top.index.name = "Facility"
    top = top.reset_index()

    display_cols = ["Facility", "forge_rank", "forge_va", "score_b1", "score_b2", "score_b3"]
    if "oig_label" in top.columns:
        display_cols.append("oig_label")
    if "classification" in top.columns:
        display_cols.append("classification")
    display_cols = [c for c in display_cols if c in top.columns]

    print(f"\n{'='*72}")
    print(f"TOP {len(top)} FACILITIES BY forge_va")
    print(f"{'='*72}")
    with pd.option_context("display.max_rows", None, "display.width", 140):
        print(top[display_cols].to_string(index=False, float_format=lambda x: f"{x:.4f}"))

    top_path = scores_out.rsplit(".", 1)[0] + f"_top{top_k}.csv"
    top[display_cols].to_csv(top_path, index=False)
    print(f"\nSaved top-{top_k} list -> {top_path}")


def cmd_fit(args: argparse.Namespace) -> None:
    print(f"Loading SAIL from {args.sail} ...")
    sail = load_sail(args.sail)
    print(f"Loading VAC3 from {args.vac3} ...")
    vac3 = load_vac3(args.vac3)

    print("Computing Block 1 (SAIL outcome signal) ...")
    b1 = compute_block1(sail)
    print(f"  {len(b1)} facilities with valid Block 1 features")

    print("Computing Block 2 (VAC3 behavioral signal, exact Mahalanobis + "
          "Isolation Forest per measure group) -- this is the slow step ...")
    b2 = compute_block2(vac3)
    print(f"  {len(b2)} facilities with valid Block 2 features")

    # Match against the ACTUAL scoring panel (Block 2/VAC3-based, per the
    # exact panel-construction rule in build_blocks), not the SAIL/VAC3
    # union -- matching against the union previously caused bg_set to
    # include facilities absent from the real panel, inflating the
    # reported background count.
    panel_index = b2.index
    print(f"Matching ground truth from {args.ground_truth} (fuzzy, exact port of the "
          f"production notebook's matcher) ...")
    fraud_set, n_set, bg_set, gt_audit = match_ground_truth_fuzzy(panel_index, args.ground_truth)
    print(f"  S={len(fraud_set)}  N={len(n_set)}  bg={len(bg_set)}")
    if len(fraud_set) < 5:
        print("WARNING: fewer than 5 matched confirmed (S) facilities -- "
              "rank-biserial weight estimates will be unstable. Proceeding anyway.")

    master, eff_all = build_blocks(b1, b2, fraud_set, n_set, bg_set)
    master, eff_ens = build_ensemble(master, fraud_set, n_set, bg_set)
    eff_all = pd.concat([eff_all, eff_ens], ignore_index=True)

    for col in ["score_b1", "score_b2", "score_b3", "forge_va"]:
        auc = quick_auc(master[col], fraud_set, bg_set)
        print(f"  AUC-ROC {col:<12} (S vs bg) = {auc:.4f}")

    master["classification"] = _classify(master, args.top_pct)
    master["oig_label"] = np.where(
        master.index.isin(fraud_set), "S",
        np.where(master.index.isin(n_set), "N",
                 np.where(master.index.isin(bg_set), "bg", "unmatched")),
    )

    save_weights(args.weights_out, eff_all)
    print(f"Saved weights -> {args.weights_out}")

    eff_path = args.scores_out.rsplit(".", 1)[0] + "_effect_sizes.csv"
    eff_all.to_csv(eff_path, index=False)
    print(f"Saved effect-size table -> {eff_path}")

    master.sort_values("forge_va", ascending=False).to_csv(args.scores_out)
    print(f"Saved scores -> {args.scores_out}")

    _report_top_k(master, args.top_k, args.scores_out)


def cmd_score(args: argparse.Namespace) -> None:
    print(f"Loading SAIL from {args.sail} ...")
    sail = load_sail(args.sail)
    print(f"Loading VAC3 from {args.vac3} ...")
    vac3 = load_vac3(args.vac3)

    print("Computing Block 1 (SAIL outcome signal) ...")
    b1 = compute_block1(sail)
    print("Computing Block 2 (VAC3 behavioral signal) ...")
    b2 = compute_block2(vac3)

    print(f"Loading fitted weights from {args.weights_in} ...")
    weights_payload = load_weights(args.weights_in)

    # Same panel-construction rule as build_blocks (fit mode): VAC3/Block 2
    # defines the panel, SAIL/Block 1 is left-joined onto it.
    master = b2.join(b1, how="left")
    master = score_with_fixed_weights(master, weights_payload)
    master["classification"] = _classify(master, args.top_pct)

    n_scored = master["forge_va"].notna().sum()
    print(f"Scored {n_scored} facilities (no ground truth used -- weights "
          f"were fit previously and applied as-is).")

    master.sort_values("forge_va", ascending=False).to_csv(args.scores_out)
    print(f"Saved scores -> {args.scores_out}")

    _report_top_k(master, args.top_k, args.scores_out)


def main():
    parser = argparse.ArgumentParser(
        description="Run the FORGE-VA gaming-detection pipeline.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_fit = sub.add_parser("fit", help="Fit weights against labeled (OIG ground-truth) data and score it.")
    p_fit.add_argument("--sail", required=True)
    p_fit.add_argument("--vac3", required=True)
    p_fit.add_argument("--ground-truth", required=True)
    p_fit.add_argument("--weights-out", required=True)
    p_fit.add_argument("--scores-out", required=True)
    p_fit.add_argument("--top-pct", type=float, default=0.10)
    p_fit.add_argument("--top-k", type=int, default=None,
                        help="Print and save the top K facilities by forge_va to their own file "
                             "(<scores-out base>_topK.csv). Omit to skip.")
    p_fit.set_defaults(func=cmd_fit)

    p_score = sub.add_parser("score", help="Score new, unlabeled data using previously-fit weights.")
    p_score.add_argument("--sail", required=True)
    p_score.add_argument("--vac3", required=True)
    p_score.add_argument("--weights-in", required=True)
    p_score.add_argument("--scores-out", required=True)
    p_score.add_argument("--top-pct", type=float, default=0.10)
    p_score.add_argument("--top-k", type=int, default=None,
                          help="Print and save the top K facilities by forge_va to their own file "
                               "(<scores-out base>_topK.csv). Omit to skip.")
    p_score.set_defaults(func=cmd_score)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
