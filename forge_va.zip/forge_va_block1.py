"""
forge_va_block1.py -- SAIL Outcome Signal (Block 1)

EXACT port of the production notebook's SAIL normalization cell + SAIL
"Multi-Measures" feature-engineering cell. Block 1 is NOT the simplified
mean_z/pct_high/slope set an earlier version of this wrapper used -- it is
structurally the SAME rich fac_summary template as Block 2 (mean_anom,
bunching_rate, mean_mahalanobis, etc.), computed on SAIL data instead of
VAC3 data, with two SAIL-specific differences from Block 2's construction:

  1. Z_vs_National = (Score - Group_Mean) / SE -- relative to the SAIL
     cohort's OWN mean, not an external National_Benchmark column (SAIL
     has no such column). Z_vs_VISN plays the "regional" role VAC3's
     Z_vs_Regional plays, grouped by VISN instead of a Regional_Benchmark
     column.
  2. Direction sign: +1 if Direction_norm=="higher", -1 if "lower", and
     -- unlike VAC3's binary "higher else negate" rule -- an UNKNOWN
     direction leaves the Z-score unsigned (passed through as-is) rather
     than negated. This is a real, deliberate difference in the source
     notebook, not a simplification; replicated exactly here.

Everything downstream of the signed Z-scores (Measure_Difficulty_Weight,
GoodZ_Weighted, the Z_baseline/Z_resid/Z_resid_delta/Z_resid_roll_std4
residual chain, TSLF, Facility_Consistency_SD, Pct_Measures_Improving,
reference-point proximity/Is_Bunched, the exact global-covariance
Mahalanobis distance, Isolation Forest per measure group, and the
fac_summary rollup) is identical in structure to Block 2 and is applied
here via the same MIN_OBS_PER_MEASURE / GOOD_Z_MIN / ANOMALY_QUANTILE /
CANONICAL_THRESHOLDS / BUNCHING_WINDOW / MAHALANOBIS_FEATURES /
FINAL_FEATURE_COLS constants (confirmed identical to Block 2's in the
source notebook).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from forge_va_core import read_table
from forge_va_block2 import (
    MIN_OBS_PER_MEASURE, GOOD_Z_MIN, ANOMALY_QUANTILE, CANONICAL_THRESHOLDS,
    BUNCHING_WINDOW, MAHALANOBIS_FEATURES, FINAL_FEATURE_COLS,
    _fy_to_year, _q_to_int, _max_streak,
    _calculate_mahalanobis_distance, _fit_isolation_forest_per_measure,
)


def load_sail(sail_path: str) -> pd.DataFrame:
    df = read_table(sail_path, dtype={"FY": str, "Quarter": str, "VISN": str})
    # Ensure these are strings regardless of source format -- CSV honors
    # the dtype= hint above, but a Parquet file may have stored FY/Quarter
    # as ints if it wasn't written carefully; force it here so the
    # downstream regex-based FY/Quarter parsing works either way.
    for col in ("FY", "Quarter", "VISN"):
        if col in df.columns:
            df[col] = df[col].astype(str)
    required = {"Facility", "Measure", "Score", "Direction", "FY", "Quarter", "VISN"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"SAIL file missing required columns for EXACT Block 1 construction: {missing}."
        )
    df["Measure"] = df["Measure"].apply(lambda s: s.strip() if isinstance(s, str) else s)
    df = df[~df["Measure"].isna() & (df["Measure"] != "")].copy()
    df["Facility"] = df["Facility"].astype(str).str.strip().str.upper()
    df["_fac_key"] = df["Facility"]  # matches real pipeline's index convention
    df["Score"] = pd.to_numeric(df["Score"], errors="coerce")
    return df


_DIR_LUT = {
    "high": "higher", "higher is better": "higher", "high is better": "higher",
    "low": "lower", "lower is better": "lower", "low is better": "lower",
    "higher": "higher", "lower": "lower", "up": "higher", "down": "lower",
}


def _norm_dir(x):
    if pd.isna(x):
        return None
    return _DIR_LUT.get(str(x).strip().lower(), None)


def _se_based_normalization_sail(df: pd.DataFrame) -> pd.DataFrame:
    """Exact port of the SAIL 'normalization vs National & VISN benchmarks
    (SE-based)' cell. Unlike VAC3, Z is relative to the cohort's own mean,
    not an external benchmark column."""
    df = df.copy()
    df["Direction_norm"] = df["Direction"].apply(_norm_dir)

    df_valid = df[df["Score"].notna()].copy()

    grp_nat = ["Measure", "FY", "Quarter"]
    nat_stats = (
        df_valid.groupby(grp_nat)["Score"]
        .agg(Group_N="count", Group_SD=lambda x: x.std(ddof=1), Group_Mean="mean")
        .reset_index()
    )
    df = df.merge(nat_stats, on=grp_nat, how="left")
    df["SE"] = df["Group_SD"] / (df["Group_N"] ** 0.5)

    grp_visn = ["Measure", "FY", "Quarter", "VISN"]
    visn_stats = (
        df_valid.groupby(grp_visn)["Score"]
        .agg(Group_N_VISN="count", Group_SD_VISN=lambda x: x.std(ddof=1), Group_Mean_VISN="mean")
        .reset_index()
    )
    df = df.merge(visn_stats, on=grp_visn, how="left")
    df["SE_VISN"] = df["Group_SD_VISN"] / (df["Group_N_VISN"] ** 0.5)

    n, se = df["Group_N"].values, df["SE"].values
    valid_nat = df["Score"].notna() & (n >= 2) & (se != 0) & ~pd.isna(se)
    df["Z_vs_National"] = np.where(valid_nat, (df["Score"] - df["Group_Mean"]) / se, np.nan)

    n_v, se_v = df["Group_N_VISN"].values, df["SE_VISN"].values
    valid_visn = df["Score"].notna() & (n_v >= 2) & (se_v != 0) & ~pd.isna(se_v)
    df["Z_vs_VISN"] = np.where(valid_visn, (df["Score"] - df["Group_Mean_VISN"]) / se_v, np.nan)

    return df


def _build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = _se_based_normalization_sail(df)

    # ---- direction-signed Z: EXACT SAIL rule (unknown direction -> unsigned pass-through) ----
    dir_series = df["Direction_norm"].fillna("").str.lower()
    sign = np.where(dir_series == "higher", 1.0, np.where(dir_series == "lower", -1.0, np.nan))
    df["Z_nat_signed"] = sign * df["Z_vs_National"]
    df["Z_visn_signed"] = sign * df["Z_vs_VISN"]
    unknown = pd.isna(sign)
    df.loc[unknown, "Z_nat_signed"] = df.loc[unknown, "Z_vs_National"]
    df.loc[unknown, "Z_visn_signed"] = df.loc[unknown, "Z_vs_VISN"]

    df["GoodZ_nat"] = np.clip(df["Z_nat_signed"], 0, None)
    df["Z_delta"] = df["Z_nat_signed"] - df["Z_visn_signed"]

    df["Measure_Difficulty_Weight"] = 1.0 / df["Group_SD"]
    is_inf = df["Measure_Difficulty_Weight"].isin([np.inf, -np.inf])
    df.loc[is_inf, "Measure_Difficulty_Weight"] = 1000
    df["Measure_Difficulty_Weight"] = df["Measure_Difficulty_Weight"].fillna(0)
    df["GoodZ_Weighted"] = df["GoodZ_nat"] * df["Measure_Difficulty_Weight"]

    df["Year"] = df["FY"].apply(_fy_to_year)
    df["Qnum"] = df["Quarter"].apply(_q_to_int)
    df["time_ord"] = (
        pd.to_numeric(df["Year"], errors="coerce").fillna(0).astype(int) * 4
        + (pd.to_numeric(df["Qnum"], errors="coerce").fillna(1).astype(int) - 1)
    )
    df = df.sort_values(["_fac_key", "Measure", "time_ord"], kind="mergesort").reset_index(drop=True)

    g = df.groupby(["_fac_key", "Measure"], dropna=False, group_keys=False)
    roll_mean = g["Z_nat_signed"].transform(lambda x: x.rolling(window=4, min_periods=2).mean().shift(1))
    df["Z_baseline"] = roll_mean.fillna(g["Z_nat_signed"].transform("mean"))
    df["Z_baseline"] = df["Z_baseline"].fillna(df["Z_nat_signed"].mean())

    df["Z_resid"] = df["Z_nat_signed"] - df["Z_baseline"]
    df["Z_resid_lag"] = g["Z_resid"].shift(1)
    df["Z_resid_delta"] = df["Z_resid"] - df["Z_resid_lag"]
    df["Z_resid_roll_std4"] = g["Z_resid"].transform(lambda x: x.rolling(window=4, min_periods=2).std())

    df["is_good"] = (df["Z_nat_signed"] > 1.0).astype(int)

    def _tslf(series: pd.Series) -> pd.Series:
        out, last_good = [], None
        for i, flag in enumerate(series):
            if flag == 1:
                out.append(0)
                last_good = i
            else:
                out.append(np.nan if last_good is None else i - last_good)
        return pd.Series(out, index=series.index)

    df["TSLF"] = g["is_good"].apply(_tslf)
    df["TSLF"] = df["TSLF"].clip(lower=0)

    fac_q = df.groupby(["_fac_key", "time_ord"], dropna=False)
    df["Facility_Consistency_SD"] = fac_q["Z_nat_signed"].transform("std")
    df["Pct_Measures_Improving"] = fac_q["Z_resid_delta"].transform(
        lambda x: (x > 0).mean() if x.notna().sum() > 0 else np.nan
    )

    def _min_dist(z):
        if pd.isna(z):
            return np.nan
        return min(abs(z - t) for t in CANONICAL_THRESHOLDS)

    df["Min_Dist_to_Threshold"] = df["Z_nat_signed"].apply(_min_dist)
    df["Is_Bunched"] = (df["Min_Dist_to_Threshold"] <= BUNCHING_WINDOW).astype(int)
    df["Facility_Quarter_Bunching_Rate"] = fac_q["Is_Bunched"].transform("mean")

    return df


def compute_block1(sail: pd.DataFrame) -> pd.DataFrame:
    """Full, exact Block 1 pipeline -- structurally identical output
    schema to compute_block2, computed on SAIL/VISN inputs."""
    df = _build_features(sail)

    df["Mahalanobis_D"] = _calculate_mahalanobis_distance(df.copy(), MAHALANOBIS_FEATURES)

    group_col = "Measure_canon" if "Measure_canon" in df.columns else "Measure"
    df["IF_anomaly_score"] = _fit_isolation_forest_per_measure(df, group_col)

    raw_scores = df["IF_anomaly_score"].values
    valid = np.isfinite(raw_scores)
    if valid.sum() == 0:
        threshold = np.inf
        df["IF_flag_all"] = 0
    else:
        threshold = np.quantile(raw_scores[valid], ANOMALY_QUANTILE)
        df["IF_flag_all"] = (df["IF_anomaly_score"] >= threshold).astype(int)

    good_side = df["Z_nat_signed"] > GOOD_Z_MIN
    df["IF_good_flag"] = ((df["IF_flag_all"] == 1) & good_side).astype(int)

    df["_time_sort"] = df["time_ord"]
    fac_groups = df.sort_values(["_fac_key", "_time_sort", "Measure"]).groupby("_fac_key", dropna=False)

    fac_summary = pd.DataFrame({
        "records": fac_groups.size(),
        "mean_anom": fac_groups["IF_anomaly_score"].mean(),
        "p95_anom": fac_groups["IF_anomaly_score"].quantile(0.95),
        "pct_flagged_good": fac_groups["IF_good_flag"].mean(),
        "pct_flagged_all": fac_groups["IF_flag_all"].mean(),
        "unique_measures": fac_groups["Measure"].nunique(),
        "years_covered": fac_groups["Year"].nunique(),
        "mean_mahalanobis": fac_groups["Mahalanobis_D"].mean(),
        "p95_mahalanobis": fac_groups["Mahalanobis_D"].quantile(0.95),
        "mean_z_consistency_sd": fac_groups["Facility_Consistency_SD"].mean(),
        "mean_goodz_weighted": fac_groups["GoodZ_Weighted"].mean(),
        "max_tslf": fac_groups["TSLF"].max(),
        "bunching_rate": fac_groups["Is_Bunched"].mean(),
        "mean_bunching_rate_per_quarter": fac_groups["Facility_Quarter_Bunching_Rate"].mean(),
        "p95_bunching_rate": fac_groups["Facility_Quarter_Bunching_Rate"].quantile(0.95),
        "mean_dist_to_threshold": fac_groups["Min_Dist_to_Threshold"].mean(),
        "mean_pct_improving": fac_groups["Pct_Measures_Improving"].mean(),
        "p95_pct_improving": fac_groups["Pct_Measures_Improving"].quantile(0.95),
        "sd_pct_improving": fac_groups["Pct_Measures_Improving"].std(),
    })

    streaks = []
    for fac, grp in df.sort_values(["_fac_key", "_time_sort"]).groupby("_fac_key", dropna=False):
        streaks.append((fac, _max_streak(grp["IF_good_flag"].tolist())))
    streak_df = pd.DataFrame(streaks, columns=["_fac_key", "max_good_flag_streak"]).set_index("_fac_key")
    fac_summary = fac_summary.join(streak_df, how="left")

    # prefix, matching how the real notebook distinguishes Block 1 signals
    # in `master` (columns starting with "sail_full_")
    fac_summary = fac_summary.add_prefix("sail_full_")
    fac_summary.index.name = "_fac_key"
    return fac_summary
