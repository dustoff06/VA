"""
forge_va_fit.py -- EXACT port of build_weighted_score_dual, Block 3
coupling, ensemble weighting, and weight persistence.

VAC3_SIGNALS below is copied verbatim (keys and directions) from the
production notebook's Block 2 scoring cell. The Block 1 signal set is
NOT a static dict here (there isn't one in the source notebook either) --
it's built dynamically in build_blocks() from any master column prefixed
`sail_full_` / `sail_early_`, exactly matching the production notebook's
own `B1_SIGNALS = {c: +1 for c in master.columns if
c.startswith("sail_full_") or c.startswith("sail_early_")}`.

FIX (this version): score_b3 (Block 3 coupling) no longer floors missing
block ranks at 0.25 before multiplying. An earlier version of this file
did `rank_norm(...).fillna(0.25).clip(lower=0.25)` defensively so
score_b3/forge_va would never be NaN -- but this was NOT what the
production notebook does, and it silently gave every facility a non-null
ensemble score even when Block 1 or Block 2 data was genuinely missing
for it. Confirmed against a live run of the real notebook: the published
"149-facility analytic panel" is specifically
`master['forge_va'].notna().sum()`, not `len(master)` (which is 182,
matching this wrapper's Block 2 facility count exactly) -- i.e. the real
pipeline DOES let missingness propagate through Block 3 into forge_va,
and "the panel" is implicitly defined as whichever facilities end up
with a complete, valid ensemble score. rank_norm(...) with no fillna/clip
now matches that behavior: score_b3 is NaN whenever score_b1 or score_b2
is NaN, and such facilities are correctly excluded from AUC/effect-size
calculations (which already drop NaNs) and will show as NaN in exported
score files rather than getting a synthetic floor score.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from forge_va_core import rank_norm, effect_size_weight, quick_auc, _normalize_key

# EXACT, verbatim from the production notebook's Block 2 cell.
VAC3_SIGNALS = {
    "pct_flagged_good": +1,
    "bunching_rate": +1,
    "mean_pct_improving": +1,
    "p95_pct_improving": +1,
    "mean_anom": +1,
    "p95_anom": +1,
    "mean_mahalanobis": +1,
    "p95_mahalanobis": +1,
    "mean_goodz_weighted": +1,
    "mean_z_consistency_sd": +1,
    "max_good_flag_streak": +1,
    "max_tslf": +1,
    "mean_dist_to_threshold": -1,
    "sd_pct_improving": -1,
    "bunching_x_improving": +1,
}


def build_weighted_score_dual(df: pd.DataFrame, signals: dict,
                               fraud_set: set, n_set: set, bg_set: set,
                               label: str) -> tuple[pd.Series, pd.DataFrame]:
    """EXACT port of the production notebook's dual-framing effect-size
    weighting: each signal is evaluated both as S-vs-bg and (S+N)-vs-bg;
    the S+N framing is used only when it both improves the effect size
    AND N does not itself look like S relative to bg (i.e. the signal
    isn't just picking up "was investigated" rather than "was confirmed
    gaming"). Weights are the resulting r, and the final score is the
    r-weighted average of rank-normalized, direction-adjusted signals."""
    sn_set = fraud_set | n_set
    eff_rows = []
    w_sum = pd.Series(0.0, index=df.index)
    w_tot = pd.Series(0.0, index=df.index)

    for col, direction in signals.items():
        if col not in df.columns:
            continue

        s_v = df.loc[df.index.isin(fraud_set), col].dropna().values * direction
        n_v = df.loc[df.index.isin(n_set), col].dropna().values * direction
        sn_v = df.loc[df.index.isin(sn_set), col].dropna().values * direction
        bg_v = df.loc[df.index.isin(bg_set), col].dropna().values * direction

        r_s, p_s = effect_size_weight(s_v, bg_v)
        r_sn, p_sn = effect_size_weight(sn_v, bg_v)
        r_n_bg, p_n_bg = effect_size_weight(n_v, bg_v)

        use_sn = (r_sn > r_s) and (r_n_bg < r_s)
        r_used = r_sn if use_sn else r_s
        p_used = p_sn if use_sn else p_s
        framing = "S+N" if use_sn else "S"

        eff_rows.append({
            "block": label, "signal": col, "direction": direction,
            "r_s": round(r_s, 4), "p_s": round(p_s, 4),
            "r_sn": round(r_sn, 4), "p_sn": round(p_sn, 4),
            "r_n_bg": round(r_n_bg, 4), "p_n_bg": round(p_n_bg, 4),
            "r_used": round(r_used, 4), "p_used": round(p_used, 4),
            "framing_used": framing,
        })

        if r_used <= 0:
            continue

        rn = rank_norm(df[col], direction)
        valid = rn.notna()
        w_sum.loc[valid] += rn.loc[valid] * r_used
        w_tot.loc[valid] += r_used

    score = w_sum / w_tot.replace(0, np.nan)
    return score, pd.DataFrame(eff_rows)


def build_blocks(b1: pd.DataFrame, b2: pd.DataFrame,
                  fraud_set: set, n_set: set, bg_set: set) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Joins Block 1 and Block 2 facility tables, fits score_b1, score_b2
    via the exact dual-framing weighting, and computes score_b3 (coupling).
    Returns (master, effect_size_table).

    B1 signal set is built dynamically from any column prefixed
    `sail_full_` / `sail_early_` -- EXACT match to the production
    notebook's `B1_SIGNALS = {c: +1 for c in master.columns if
    c.startswith("sail_full_") or c.startswith("sail_early_")}`.

    score_b3 = rank_norm(score_b1) * rank_norm(score_b2), with NO floor
    on missing values -- a facility missing score_b1 or score_b2 gets a
    NaN score_b3, matching the production notebook exactly (see module
    docstring)."""
    # EXACT panel-construction rule: the analytic panel is defined by
    # Block 2 (VAC3) alone -- `master = vac3.set_index("Facility")` in the
    # source notebook -- with Block 1 (SAIL) left-joined onto it
    # afterward. Facilities present only in SAIL and not in VAC3 are
    # therefore dropped, not unioned in.
    master = b2.join(b1, how="left")

    master["score_b2"], eff_b2 = build_weighted_score_dual(
        master, VAC3_SIGNALS, fraud_set, n_set, bg_set, "B2_VAC3"
    )

    b1_signals = {c: +1 for c in master.columns if c.startswith("sail_full_") or c.startswith("sail_early_")}
    master["score_b1"], eff_b1 = build_weighted_score_dual(
        master, b1_signals, fraud_set, n_set, bg_set, "B1_SAIL"
    )

    # No fillna/clip floor here -- NaN in either block propagates to
    # score_b3, matching the confirmed behavior of the real pipeline.
    b1_rn = rank_norm(master["score_b1"])
    b2_rn = rank_norm(master["score_b2"])
    master["score_b3"] = b1_rn * b2_rn

    eff_all = pd.concat([eff_b1, eff_b2], ignore_index=True)
    return master, eff_all


def build_ensemble(master: pd.DataFrame, fraud_set: set, n_set: set,
                    bg_set: set) -> tuple[pd.DataFrame, pd.DataFrame]:
    blocks = {"score_b1": +1, "score_b2": +1, "score_b3": +1}
    master = master.copy()
    master["forge_va"], eff_ens = build_weighted_score_dual(
        master, blocks, fraud_set, n_set, bg_set, "Ensemble"
    )
    master["forge_rank"] = master["forge_va"].rank(
        ascending=False, method="min", na_option="bottom"
    ).astype(int)
    return master, eff_ens


def save_weights(path: str, eff_table: pd.DataFrame) -> None:
    """Saves the fitted r_used AND direction per signal, per block --
    self-describing, so score mode can replay build_weighted_score_dual's
    combination step exactly without needing any static signal-list
    constant (important for Block 1, whose signal set is itself dynamic
    at fit time -- see forge_va_block1.py's module docstring)."""
    weights_by_block: dict[str, dict[str, dict]] = {}
    directions_by_block: dict[str, dict[str, int]] = {}
    for _, row in eff_table.iterrows():
        block, signal = row["block"], row["signal"]
        weights_by_block.setdefault(block, {})[signal] = {"r_used": row["r_used"]}
        directions_by_block.setdefault(block, {})[signal] = int(row["direction"])

    payload = {"weights_by_block": weights_by_block, "directions_by_block": directions_by_block}
    Path(path).write_text(json.dumps(payload, indent=2))


def load_weights(path: str) -> dict:
    return json.loads(Path(path).read_text())


def score_with_fixed_weights(df: pd.DataFrame, weights_payload: dict) -> pd.DataFrame:
    """Applies previously-fit r_used weights to new (unlabeled) data --
    the 'score' CLI mode. No ground truth needed here.

    score_b3 has NO floor on missing values (see module docstring): a
    facility missing score_b1 or score_b2 in the new data will correctly
    come back with score_b3 = NaN and forge_va = NaN / forge_rank at the
    bottom, rather than receiving a synthetic floor score. Downstream
    consumers should treat NaN forge_va as "insufficient data to score",
    not as "lowest risk" -- the CLI's classification column already
    labels these rows "insufficient_data" rather than "routine"."""
    df = df.copy()

    def _combine(block_name: str) -> pd.Series:
        block_weights = weights_payload["weights_by_block"].get(block_name, {})
        block_dirs = weights_payload["directions_by_block"].get(block_name, {})
        w_sum = pd.Series(0.0, index=df.index)
        w_tot = pd.Series(0.0, index=df.index)
        for col, direction in block_dirs.items():
            if col not in df.columns:
                continue
            r_used = block_weights[col]["r_used"]
            if r_used <= 0:
                continue
            rn = rank_norm(df[col], direction)
            valid = rn.notna()
            w_sum.loc[valid] += rn.loc[valid] * r_used
            w_tot.loc[valid] += r_used
        return w_sum / w_tot.replace(0, np.nan)

    df["score_b2"] = _combine("B2_VAC3")
    df["score_b1"] = _combine("B1_SAIL")

    # No fillna/clip floor here either -- see module docstring.
    b1_rn = rank_norm(df["score_b1"])
    b2_rn = rank_norm(df["score_b2"])
    df["score_b3"] = b1_rn * b2_rn

    df["forge_va"] = _combine("Ensemble")
    df["forge_rank"] = df["forge_va"].rank(ascending=False, method="min", na_option="bottom").astype(int)
    return df
